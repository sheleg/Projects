package bsu.fpmi.educational_practice2017;

/**
 *
 * @author Suerte.Mind
 */
public interface AnswerListener extends java.util.EventListener {
    public void Result(AnswerEvent e);
}

Multithreading			http://msdn2.microsoft.com/en-us/library/172d2hhw.aspx
WaitForSingleObject		http://msdn2.microsoft.com/en-us/library/ms687032.aspx
WaitForSingleObjectEx		http://msdn2.microsoft.com/en-us/library/ms687036.aspx
WaitForMultipleObjects		http://msdn2.microsoft.com/en-us/library/ms687025.aspx
WaitForMultipleObjectsEx	http://msdn2.microsoft.com/en-us/library/ms687028.aspx
GetLastError			http://msdn2.microsoft.com/en-us/library/ms679360.aspx

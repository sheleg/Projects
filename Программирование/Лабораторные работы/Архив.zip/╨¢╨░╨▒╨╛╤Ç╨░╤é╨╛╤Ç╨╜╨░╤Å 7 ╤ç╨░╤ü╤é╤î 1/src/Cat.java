/**
 * Created by vladasheleg on 20.10.16.
 */
public class Cat extends Pet {
    public Cat() {
        super();
    }

    public Cat(String name, int age, int weight) {
        super(name, age, weight);
    }
}

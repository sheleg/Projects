/**
 * Created by vladasheleg on 20.10.16.
 */
public class Parrot extends Pet {
    public Parrot() {
        super();
    }

    public Parrot(String name, int age, int weight) {
        super(name, age, weight);
    }
}

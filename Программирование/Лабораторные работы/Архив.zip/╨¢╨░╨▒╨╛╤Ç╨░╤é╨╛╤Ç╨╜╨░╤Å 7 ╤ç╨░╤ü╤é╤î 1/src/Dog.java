/**
 * Created by vladasheleg on 20.10.16.
 */
public class Dog extends Pet {
    public Dog() {
        super();
    }

    public Dog(String name, int age, int weight) {
        super(name, age, weight);
    }
}

/**
 * Created by vladasheleg on 16.11.16.
 */
interface CMD {
    byte CMD_CONNECT         = 1;
    byte CMD_DISCONNECT      = 2;
    byte CMD_USER            = 3;
    byte CMD_CHECK_MAIL      = 4;
    byte CMD_LETTER          = 5;
    byte CMD_CONNECT_USER    = 6;
    byte CMD_DISCONNECT_USER = 7;
}
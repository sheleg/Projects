/**
 * Created by vladasheleg on 16.11.16.
 */
interface PORT {
    int PORT = 4422;
}
/**
 * Created by vladasheleg on 16.11.16.
 */
interface RESULT {
    int RESULT_CODE_OK      = 0;
    int RESULT_CODE_ERROR   = -1;
}